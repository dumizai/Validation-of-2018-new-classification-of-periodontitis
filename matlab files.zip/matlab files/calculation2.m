function Distance2 = calculation2(rawDataMatrix, heightofTable, demographicalIndex, bleedingIndexRange, widthofTable, maxValue, minValue)
temp1 = zeros(heightofTable,heightofTable);
temp2 = zeros(heightofTable,heightofTable);
for i = 1 : heightofTable
    for j = i + 1 : heightofTable
        for k = 1 : bleedingIndexRange            % factors about bleeding
            frpintf('ma');
            %% both patients have records
            if rawDataMatrix(i,demographicalIndex + k) < 9 && rawDataMatrix(j,demographicalIndex + k) < 9  
                if rawDataMatrix(i, demographicalIndex + k) ~= rawDataMatrix(j, demographicalIndex + k)
                temp1(i,j) = temp1(i,j) + 1;
                else
                temp1(i,j) = temp1(i,j);
                end
            %% if only one patient has record
            elseif rawDataMatrix(i, demographicalIndex + k) >= 9 || rawDataMatrix(j, demographicalIndex + k)>= 9
                temp1(i,j) = temp1(i,j) + 1;
            %% if both patients have no records
            else
                temp1(i,j) = temp1(i,j) + 1;
            end  
        end
    end
end
for i = 1 : heightofTable
    for j = i + 1 : heightofTable
        for k = demographicalIndex + bleedingIndexRange + 1 : widthofTable
            %% both patients have records
            if rawDataMatrix(i, k) < 99 && rawDataMatrix(j, k) < 99  
                temp2(i,j) = temp2(i,j) + abs( rawDataMatrix(i, k) - rawDataMatrix(j, k) )/ ( maxValue(1, k - (demographicalIndex + bleedingIndexRange) ) - minValue(1, k - (demographicalIndex + bleedingIndexRange)) );
            %% if only one patient has record
            elseif rawDataMatrix(i, k) >= 99 && rawDataMatrix(j, k)< 99  % patient i loses the tooth k
                temp2(i,j) = temp2(i,j) + abs( maxValue(1, k - (demographicalIndex + bleedingIndexRange) ) - rawDataMatrix(j, k) )/ ( maxValue(1, k - (demographicalIndex + bleedingIndexRange) ) - minValue(1, k - (demographicalIndex + bleedingIndexRange)) );
            elseif rawDataMatrix(i, k) < 99 && rawDataMatrix(j, k) >= 99 % patient j loses the tooth k
                temp2(i,j) = temp2(i,j) + abs( maxValue(1, k - (demographicalIndex + bleedingIndexRange) ) - rawDataMatrix(i, k) )/ ( maxValue(1, k - (demographicalIndex + bleedingIndexRange) ) - minValue(1, k - (demographicalIndex + bleedingIndexRange)) );
            %% if both patients have lost the same tooth
            else
                                temp2(i,j) = temp2(i,j) + 0;
            end   
        end

    end
end    
Distance2 = temp1 + temp2;
Distance2 = Distance2 + Distance2';
end

