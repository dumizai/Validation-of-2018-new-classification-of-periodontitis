clc
clear
%% convert csv files to matlab tables
rawDataTable1 = readtable('perio_demo_2009.csv');  
rawDataTable2 = readtable('perio_demo_2011.csv');
rawDataTable3 = readtable('perio_demo_2013.csv');
widthofTable = width(rawDataTable1(1,:));
heightofTable = height(rawDataTable1(:,1));
%% remove columns of CJ
initialArray = [4 5 6 7 8 9];
gap = 18;
removeIndexArray = zeros(1, widthofTable);
len1 = length(initialArray);
temp = floor((widthofTable - initialArray(1,1) + 1)/gap);
for i = 1 :temp
      removeIndexArray(1, (i - 1) * len1 + 1 : i * len1) = initialArray + (i - 1) * gap * ones(1, len1);
end
removeIndexArray = nonzeros(removeIndexArray)';
rawDataTable1(:,removeIndexArray) = [];
rawDataTable2(:,removeIndexArray) = [];
rawDataTable3(:,removeIndexArray) = [];
rawDataTable = [rawDataTable1; rawDataTable2;rawDataTable3];   % merge the tables from 2009 - 2013

%% convert matlab table to matlab array, and replace 'NaN', 'NA', and etc with numerical values
widthofTable = width(rawDataTable(1,:));
heightofTable = height(rawDataTable(:,1));
rawDataMatrix = zeros(heightofTable, widthofTable);
for i = 1 : heightofTable
    for j = 1 : widthofTable
        temp = table2array(rawDataTable(i,j));
        tempClass = class(temp);
        switch tempClass
            case 'double'
                if isnan(temp)
                    rawDataMatrix(i,j) = 100;       % 100 means no data for such feature
                else
                    rawDataMatrix(i,j) = temp;
                end
            case  'cell'
                if isequal(string(temp),'NA')
                     rawDataMatrix(i,j) = 100;
                else
                     rawDataMatrix(i,j) = str2double(temp);
                end
            otherwise
        end
        
    end
end
%% store the matlab array in an xlsx file
filename = 'dataMatrix.xlsx';
xlswrite(filename, rawDataMatrix);

