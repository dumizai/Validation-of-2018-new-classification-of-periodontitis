%% find the best trial for each fixed number medodids clustering
minditortionSum = zeros(1,t2);
for i = 1 : t2
    minditortionSum(1, i) = min(ditortionSum_Array(i, :));
end
%% elbow point plot
endpoint = t2;
plot(1 : 1 : endpoint, minditortionSum(1, 1 : endpoint),'-o')
xlabel('Number of medoids')
ylabel('Sum of squares of the distances')
hold on 
plot(3,minditortionSum(1,3), 'Color', 'r', 'Marker', 'p', 'MarkerFaceColor', 'r', 'MarkerSize', 14 )
hold on 
plot(4,minditortionSum(1,4), 'Color', 'r', 'Marker', 'p', 'MarkerFaceColor', 'r', 'MarkerSize', 14 )
hold on
annotation('textarrow', [0.46 0.36], [0.43 0.33], 'Color', 'red', 'String', 'suitable elbow points', 'FontSize', 12)



