clc
clear
%% read the array from the xlsx file
rawDataMatrix = xlsread('dataMatrix.xlsx');
[heightofTable widthofTable] = size(rawDataMatrix);
%% remove patients with too many missing data
indexArray = zeros(1, heightofTable);
demographicalIndex = 3;              % column 1: patient seqn; column 2: gender; column 3: age;
bleedingIndexRange = 0;              % 0: does not consider bleeding as a factor
numMissingData = 168;
for i = 1 : heightofTable
   if length( find (rawDataMatrix(i, demographicalIndex + 1 : end ) >= 99 ) ) > numMissingData   
        indexArray(1,i) = i;
    end
end
indexArray = nonzeros(indexArray)';
rawDataMatrix(indexArray, :) = [];
[heightofTable widthofTable] = size(rawDataMatrix);
%% replace the missing PC/LA data with the average existing PC/LA values 
numFeatures = 168;
indexPCArray = zeros(1, numFeatures);
indexLAArray = zeros(1, numFeatures);
initialArrayPC = [4 5 6 7 8 9];
initialArrayLA = [10 11 12 13 14 15];
gap = 12;
temp = floor((widthofTable - initialArrayPC(1,1) + 1)/gap);
len1 = length(initialArrayPC);
for i = 1 : temp
    indexPCArray(1, (i - 1) * len1 + 1 : i * len1) = initialArrayPC + (i - 1) * gap * ones(1, len1);   % find the columns of PC 
    indexLAArray(1, (i - 1) * len1 + 1 : i * len1) = initialArrayLA + (i - 1) * gap * ones(1, len1);   % find the columns of LA
end    
for i = 1 : heightofTable
    temp1 = rawDataMatrix(i, indexPCArray);
    temp2 = rawDataMatrix(i, indexLAArray);
    temp11 = temp1(temp1 ~= 99);                % remove missing PC data
    temp22 = temp2(temp2 ~= 99);                % remove missing LA data
    for j = 1 : widthofTable
        if ismember(j, indexPCArray) && rawDataMatrix(i,j) == 99
            rawDataMatrix(i,j) = mean(temp11);
        end
        if ismember(j, indexLAArray) && rawDataMatrix(i,j) == 99
            rawDataMatrix(i,j) = mean(temp22);
        end
    end
end    
%% calculate the Gower's distance with respect to sociodemographic features
Distance1 = calculation1(rawDataMatrix, heightofTable, demographicalIndex);
%% find the maximum and minimum values of each feature
maxValue = zeros(1, widthofTable - (bleedingIndexRange + demographicalIndex));
minValue = zeros(1, widthofTable - (bleedingIndexRange + demographicalIndex));
for i = bleedingIndexRange + demographicalIndex + 1 : widthofTable
        tempColumn = rawDataMatrix(:, i);
        tempColumn1 = tempColumn(tempColumn ~= 99);
        tempColumn = tempColumn(tempColumn ~= 100);
        if length(tempColumn1) == length(tempColumn)   % if this feature has no missing data
        maxValue(1, i - (bleedingIndexRange + demographicalIndex)) = max(tempColumn1);
        minValue(1, i - (bleedingIndexRange + demographicalIndex)) = min(tempColumn1);
        else                                           % if this feature has missing data, use the maximum value of all features, which is 17
        maxValue(1, i - (bleedingIndexRange + demographicalIndex)) = 17;
        minValue(1, i - (bleedingIndexRange + demographicalIndex)) = min(tempColumn1);
        end
        
end
%% calculate the Gower's distance with respect to PC and LA features
Distance2 = calculation2(rawDataMatrix, heightofTable, demographicalIndex, bleedingIndexRange, widthofTable, maxValue, minValue);
w1 = 0;
w2 = 1;
%% calculate the Gower's distance with respect to all features
Distance = (w1 * Distance1 + w2 * Distance2);
%% main algorithm for k-medoids clustering
loop = 50;             % trials for each run
t1 = 4;                 % initial number of clusters
t2 = 4;                 % final number of clusters
clusterIDArray = zeros(heightofTable, loop);  % store the cluster ID of each patient for 4-medoids clustering
ditortionSum_Array = zeros(t2 -t1 + 1, loop);
for i = t1 : t2
trial = 1;   
while trial <= loop
trial = trial + 1;
fprintf('the number of medoids is %d\n',i);
fprintf('the trial number is %d\n',trial - 1);
distortion = zeros(1, heightofTable);
opts = statset('Display', 'iter');
[idx, C, sumd, D, midx, info] = kmedoids( (1 : heightofTable)', i, 'Distance', @(ZI, ZJ) Distance(ZI,ZJ), 'Options', opts);
%% record the ID arrays of all trials for 4-medoids clustering
if i == 4
    clusterIDArray(:, trial - 1) = idx;
end
%% record the sum of squares of the distances for each trial and each fixed number of clusters
for j = 1 : heightofTable
    distortion(1, j) = D(j, idx(j, 1))^2;
end
ditortionSum_Array(i, trial - 1) = sum(distortion);
end
end


