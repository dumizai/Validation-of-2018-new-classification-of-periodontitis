numClusters = 4;
%% find the trials yielding the best sum of squares of distances
bestTrials = find(ditortionSum_Array(numClusters, :) == min(ditortionSum_Array(numClusters,2 : end)));
len = length(bestTrials);
%% find the number of patients of each cluster for each trial yielding the best sum of squares of distances
countTrials = zeros(len, numClusters);
for i = 1 : len
    for j = 1 : heightofTable
        countTrials(i, clusterIDArray(j, bestTrials(1,i))) =  countTrials(i, clusterIDArray(j, bestTrials(1,i))) + 1;
    end    
end
%% record each patient and his/her cluster ID
temp_idx = [rawDataMatrix(:,1) clusterIDArray(:,bestTrials(1, 1))];  
%% calculate mean values and std of PC and LA for each cluster 
idxFinal = temp_idx(:, 2);               % second column of temp_idx records the cluster ID for each patient
numFeatures = 168;
indexPCArray = zeros(1, numFeatures);    % record the columns of PC
indexLAArray = zeros(1, numFeatures);    % record the columns of LA
initialArrayPC = [4 5 6 7 8 9];
initialArrayLA = [10 11 12 13 14 15];
gap = 12;
temp = floor((widthofTable - initialArrayPC(1,1) + 1)/gap);
len1 = length(initialArrayPC);
for i = 1 : temp
    indexPCArray(1, (i - 1) * len1 + 1 : i * len1) = initialArrayPC + (i - 1) * gap * ones(1, len1);
    indexLAArray(1, (i - 1) * len1 + 1 : i * len1) = initialArrayLA + (i - 1) * gap * ones(1, len1);
end
tempNum1 = zeros(numClusters,1);          % record the total number of missing data of LA
tempNum2 = zeros(numClusters,1);          % record the total number of missing data of PC
tempComNum1 = zeros(numClusters,1);          
tempComNum2 = zeros(numClusters,1);         
tempMean1 = zeros(numClusters,1);         % record the sum of the mean value of LA of each patient
tempMean2 = zeros(numClusters,1);         % record the sum of the mean value of PC of each patient
stdLA = zeros(numClusters, 2 * 10^6);
stdPC = zeros(numClusters, 2 * 10^6);
stdMissingLA = zeros(numClusters, heightofTable);
stdMissingPC = zeros(numClusters, heightofTable);
countMissing = zeros(1, numClusters);
for i = 1 : heightofTable
    tempLA = rawDataMatrix(i, indexLAArray);       % extract the LA info for patient i
    tempPC = rawDataMatrix(i, indexPCArray);       % extract the PC info for patient i
    temp1 = find (tempLA == 99);                   % indexes of missing data of LA of the i-th patient
    temp11 = find(tempLA ~= 99);                   % indexes of recorded data of LA of the i-th patient
    temp2 = find (tempPC == 99);                   % indexes of missing data of PC of the i-th patient
    temp22 = find(tempPC ~= 99);                   % indexes of recorded data of PC of the i-th patient
    tempNum1(idxFinal(i,1), 1) = tempNum1(idxFinal(i,1), 1) + length(temp1);
    tempNum2(idxFinal(i,1), 1) = tempNum2(idxFinal(i,1), 1) + length(temp2);
    tempComNum1(idxFinal(i,1), 1) = tempComNum1(idxFinal(i,1), 1) + length(temp11);
    tempComNum2(idxFinal(i,1), 1) = tempComNum2(idxFinal(i,1), 1) + length(temp22);           
    tempMean1(idxFinal(i,1), 1) = tempMean1(idxFinal(i,1), 1) +  sum(tempLA(1, temp11));
    tempMean2(idxFinal(i,1), 1) = tempMean2(idxFinal(i,1), 1) +  sum(tempPC(1, temp22));
    stdLA( idxFinal(i,1), tempComNum1(idxFinal(i,1), 1) - ( length(tempLA) - length(temp1) ) + 1 : tempComNum1(idxFinal(i,1), 1) ) = tempLA(1, temp11);
    stdPC( idxFinal(i,1), tempComNum2(idxFinal(i,1), 1) - ( length(tempPC) - length(temp2) ) + 1 : tempComNum2(idxFinal(i,1), 1) ) = tempPC(1, temp22);
    stdMissingLA( idxFinal(i,1), countMissing(1, idxFinal(i,1)) + 1 ) = length(temp1);
    stdMissingPC( idxFinal(i,1), countMissing(1, idxFinal(i,1)) + 1 ) = length(temp2);
    countMissing(1, idxFinal(i,1)) = countMissing(1, idxFinal(i,1)) + 1;
end
for i = 1 : numClusters
    fprintf('第 %d 个类的LA的平均值是: %d; PC的平均值是: %d\n', i, tempMean1(i,1)/tempComNum1(i,1), tempMean2(i,1)/tempComNum2(i,1)   );
    fprintf('the STD of LA of the %d-th cluster  is: %d\n', i, std(stdLA(i, 1 : tempComNum1(i,1)) ));
    fprintf('the STD of PC of the %d-th cluster  is: %d\n', i, std(stdPC(i, 1 : tempComNum2(i,1)) ));
end
%% T-SNE plot
originalData = rawDataMatrix(:,4:end);
reducedData = tsne(originalData,'Algorithm','barneshut','NumPCAComponents',50);
figure('units','inches')
pos = get(gcf,'pos');
set(gcf,'pos',[pos(1) pos(2) 6 4])
for i = 1 : heightofTable
    ll(i) = cellstr(append('cluster',' ',num2str(temp_idx(i,2))));
end
gscatter(reducedData(:,1),reducedData(:,2),ll','rmgb','.',5)
legend('FontSize', 12)
axis([-45 30 -50 60])

