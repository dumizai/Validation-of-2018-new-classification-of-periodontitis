function Distance1 = calculation1(rawDataMatrix, heightofTable, demographicalIndex)
temp1 = zeros(heightofTable,heightofTable);
temp2 = zeros(heightofTable,heightofTable);
maxAge = max(rawDataMatrix(:,3));
minAge = min(rawDataMatrix(:,3));

for i = 1 : heightofTable
    for j = i + 1 : heightofTable
        %% distancec w.r.t. gender
        if rawDataMatrix(i,2) == rawDataMatrix(j,2)
            temp1(i,j) = 0;
        else
            temp1(i,j) = 1;
        end    
        %% distance w.r.t. age
            temp2(i,j) =  abs(rawDataMatrix(i,3) - rawDataMatrix(j,3))/(maxAge - minAge);   % age : gender = 2 : 1
    end    
end

Distance1 = temp1 + temp2;
Distance1 = Distance1 + Distance1';
end

