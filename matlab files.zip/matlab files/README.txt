1. run dataConversion.m to convert csv files to matlab arrays
2. run k_medoids_clustering.m to apply the k-medoids clustering to the patients
3. t1 and t2 in k_medoids_clustering.m need to be set to 4 when running analysis.m
4. t1 is set to 1 and t2 is set to 10 when running elbow.m 